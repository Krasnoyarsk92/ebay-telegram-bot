# Telegram Bot for Railway

This is a basic async Telegram bot that runs 24/7 on Railway.

## Setup

1. Create a `.env` file and add your Telegram Bot Token:

```
TELEGRAM_BOT_TOKEN=your_token_here
```

2. Install dependencies:

```
pip install -r requirements.txt
```

3. Run locally:

```
python bot.py
```

4. Deploy to Railway:
- Push this folder to GitHub
- Import GitHub project in Railway
- Set `TELEGRAM_BOT_TOKEN` in Railway's environment variables
